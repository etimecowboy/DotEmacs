<!-- -*- markdown -*- -->

# Warning

Please note at July 2nd 2014 `o-blog` has switch to version 2 which is
compatible with version 1. Meanwhile you might experience some issues. You
can still use `o-blog 1` by using the `o-blog-v1` branch instead of
`master`.

# Major change

Now `o-blog` supports several source files:

* org-mode
* markdown

# Demo

Please have a look for a demo site and documentation:

* `o-blog-v2` http://renard.github.com/o-blog-v2
* Old `o-blog-v1` http://renard.github.com/o-blog
