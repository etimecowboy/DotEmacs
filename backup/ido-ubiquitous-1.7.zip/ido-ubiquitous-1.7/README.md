# ido-ubiquitous

Gimme some ido... everywhere!

Does what you were *really* hoping for when you did `(setq
ido-everywhere t)`. Replaces stock emacs completion with ido
completion wherever it is possible to do so without breaking things.

Get it from http://marmalade-repo.org/packages/ido-ubiquitous
